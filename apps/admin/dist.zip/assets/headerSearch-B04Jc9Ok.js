function n(r){const t=String(r||"").trim();return t?`/orders?${new URLSearchParams({q:t})}`:null}function o(r){return String((r==null?void 0:r.get("q"))||"").trim()}export{n as o,o as s};
