const c=new Set(["Myntra","Amazon"]);function a(n){return c.has(String((n==null?void 0:n.channel)||""))&&["channel_api","channel_push"].includes(n==null?void 0:n.source)}export{a as c};
