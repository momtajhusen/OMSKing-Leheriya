const m=["212222","222122","222221","121223","121322","131222","122213","122312","132212","221213","221312","231212","112232","122132","122231","113222","123122","123221","223211","221132","221231","213212","223112","312131","311222","321122","321221","312212","322112","322211","212123","212321","232121","111323","131123","131321","112313","132113","132311","211313","231113","231311","112133","112331","132131","113123","113321","133121","313121","211331","231131","213113","213311","213131","311123","311321","331121","312113","312311","332111","314111","221411","431111","111224","111422","121124","121421","141122","141221","112214","112412","122114","122411","142112","142211","241211","221114","413111","241112","134111","111242","121142","121241","114212","124112","124211","411212","421112","421211","212141","214121","412121","111143","111341","131141","114113","114311","411113","411311","113141","114131","311141","411131","211412","211214","211232"];const R="2331112",h=t=>Math.round(t/25.4*72*100)/100,u=h(51),S=h(25);function T(t){const o=String(t??"");if(!o||/[^\x20-\x7e]/.test(o))throw new Error("Barcode must be printable ASCII text");const c=[104,...[...o].map(e=>e.charCodeAt(0)-32)],n=c.reduce((e,r,d)=>e+r*(d||1),0)%103;return[...c,n].map(e=>m[e]).concat(R).join("").split("").map(Number)}function E(t){let o;try{o=T(t)}catch{return{bars:[],width:0}}const c=[];let n=0;return o.forEach((e,r)=>{r%2===0&&c.push({x:n,w:e}),n+=e}),{bars:c,width:n}}function B(t,o){const c=String(t??"").replace(/[^\x20-\x7e]/g,"?");return(c.length>o?`${c.slice(0,o-1)}~`:c).replace(/[\\()]/g,e=>`\\${e}`)}function g(t,o,c,n){const e=String(t??"").length>n?n:String(t??"").length,r=Math.max(2,(u-e*o*.6)/2);return`BT /F1 ${o} Tf ${r.toFixed(2)} ${c} Td (${B(t,n)}) Tj ET`}function L({value:t,name:o}){const c=T(t),n=c.reduce((s,i)=>s+i,0),r=Math.min(1.2,(u-8*2)/n);let d=(u-r*n)/2;const p=[];c.forEach((s,i)=>{i%2===0&&p.push(`${d.toFixed(3)} 17 ${(s*r).toFixed(3)} 42 re`),d+=s*r});const f=[g(o,6,62,38),"q 0 g",...p,"f Q",g(t,8,6,28)].join(`
`),l=["<< /Type /Catalog /Pages 2 0 R >>","<< /Type /Pages /Kids [3 0 R] /Count 1 >>",`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${u} ${S}] /Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>`,`<< /Length ${f.length} >>
stream
${f}
endstream`,"<< /Type /Font /Subtype /Type1 /BaseFont /Courier-Bold >>"];let a=`%PDF-1.4
`;const b=l.map((s,i)=>{const x=a.length;return a+=`${i+1} 0 obj
${s}
endobj
`,x}),$=a.length;return a+=`xref
0 ${l.length+1}
0000000000 65535 f 
`,a+=b.map(s=>`${String(s).padStart(10,"0")} 00000 n 
`).join(""),a+=`trailer
<< /Size ${l.length+1} /Root 1 0 R >>
startxref
${$}
%%EOF
`,a}function F({value:t,name:o}){const c=L({value:t,name:o}),n=URL.createObjectURL(new Blob([c],{type:"application/pdf"}));if(!window.open(n,"_blank")){const e=document.createElement("a");e.href=n,e.download=`barcode-${String(t).replace(/[^\w-]+/g,"_")}.pdf`,e.click()}setTimeout(()=>URL.revokeObjectURL(n),6e4)}export{E as b,F as p};
